# v1.9.1

- 5-tab bottom navigation: Home / Inventory / Stock movement / History / Other.
- Dashboard hero, quick actions, alerts, recent activity, and favorite items.
- Inventory search supports manual entry and barcode scanning; filter by category, low stock, expiry warning, and favorites.
- General users can register new items; editing/deleting item master data and category/operator management remain administrator-only.
- FEFO lot ordering (earliest expiry first) and recommended lot selection for outbound movements.
- History filters by date range, operation type, operator, and free-text query.
- Administrators can cancel new inbound/outbound/waste transactions with reversible lot deltas; original history is retained and a cancellation record is added. Older records without reversal metadata are not cancellable.
- Keeps existing offline IndexedDB stores and data format; preserves lot + expiry + receipt-date stock separation and aggregation.
- Refined teal/white medical visual system and confirmation dialog.

# v1.4.0

- Added local login screen. General users sign in with a display name and no password.
- Added first-run administrator password setup (minimum 8 characters); password verifier is stored locally using PBKDF2-HMAC-SHA256 with a random salt.
- Only an administrator session can edit inbound/outbound history.
- Editing an inbound/outbound record updates the associated lot balances and writes a separate audit history record with before/after details, editor name, and timestamp.
- History edits are limited to quantity, lot number, expiry date, and note. Transaction date and item are retained. Disposal and stock-adjustment records are not editable.
- Existing IndexedDB inventory data and GS1-128 scanning are retained; no database schema migration is required.

## Notes

- Authentication is local to this installation and this device. It is not a centrally managed identity system; anyone with device/app-data access or the ability to clear/reinstall the app may bypass local controls. Use Android device lock and keep backups secure.
- The administrator password is not included in JSON backups. Set it again if app data is cleared or the app is reinstalled and local WebView storage is lost.
- Actual Android build and on-device authentication/stock-edit tests remain required.

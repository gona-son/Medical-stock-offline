package jp.example.medicalstock;

import android.app.Activity;
import androidx.activity.ComponentActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import com.journeyapps.barcodescanner.ScanIntentResult;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends ComponentActivity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingContent = "";
    private String pendingMime = "application/json";
    private ActivityResultLauncher<ScanOptions> scanLauncher;
    private boolean gs1StackedScan = false;
    private String gs1FirstRow = "";
    private final ActivityResultLauncher<Intent> createFileLauncher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), result -> {
            boolean saved = false;
            if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null && result.getData().getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(result.getData().getData())) {
                    if (out != null) { out.write(pendingContent.getBytes(StandardCharsets.UTF_8)); saved = true; }
                    Toast.makeText(this, saved ? "ファイルを保存しました" : "保存できませんでした", Toast.LENGTH_LONG).show();
                } catch (Exception e) { Toast.makeText(this, "保存できませんでした", Toast.LENGTH_LONG).show(); }
            }
            if (webView != null) webView.evaluateJavascript("window.onNativeSaveComplete && window.onNativeSaveComplete(" + saved + ")", null);
        });
    private final ActivityResultLauncher<Intent> openFileLauncher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), result -> {
            if (fileCallback == null) return;
            Uri[] uris = null;
            if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                Uri uri = result.getData().getData(); if (uri != null) uris = new Uri[]{uri};
            }
            fileCallback.onReceiveValue(uris); fileCallback = null;
        });

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        scanLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (gs1StackedScan) {
                if (result.getContents() == null) {
                    gs1StackedScan = false; gs1FirstRow = "";
                    Toast.makeText(this, "GS1-128の読み取りを中止しました", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (gs1FirstRow.isEmpty()) {
                    gs1FirstRow = result.getContents();
                    ScanOptions next = new ScanOptions();
                    next.setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES);
                    next.setPrompt("続けて2段目のGS1-128を読み取ってください");
                    next.setBeepEnabled(false); next.setOrientationLocked(true);
                    scanLauncher.launch(next);
                } else {
                    String combined = gs1FirstRow + "\u001d" + result.getContents();
                    gs1StackedScan = false; gs1FirstRow = "";
                    if (webView != null) webView.evaluateJavascript("window.onGs1StackedScanned(" + JSONObject.quote(combined) + ")", null);
                }
                return;
            }
            if (result.getContents() != null && webView != null) {
                webView.evaluateJavascript("window.onBarcodeScanned(" + JSONObject.quote(result.getContents()) + ")", null);
            }
        });
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setSupportZoom(true);
        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                openFileLauncher.launch(intent);
                return true;
            }
        });
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                // Keep the JavaScript bridge confined to the bundled local application.
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }
    private class AppBridge {
        @JavascriptInterface public void scanBarcode() {
            runOnUiThread(() -> {
                ScanOptions options = new ScanOptions();
                options.setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES);
                options.setPrompt("商品バーコードを枠内に合わせてください");
                options.setBeepEnabled(false);
                options.setOrientationLocked(true);
                scanLauncher.launch(options);
            });
        }
        @JavascriptInterface public void scanGs1Stacked() {
            runOnUiThread(() -> {
                gs1StackedScan = true; gs1FirstRow = "";
                ScanOptions options = new ScanOptions();
                options.setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES);
                options.setPrompt("1段目のGS1-128を読み取ってください");
                options.setBeepEnabled(false); options.setOrientationLocked(true);
                scanLauncher.launch(options);
            });
        }
        @JavascriptInterface public void saveText(String filename, String mime, String content) {
            runOnUiThread(() -> {
                pendingContent = content; pendingMime = mime;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                intent.putExtra(Intent.EXTRA_TITLE, filename);
                createFileLauncher.launch(intent);
            });
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}

# v1.2.0

- Added a dedicated GS1-128 two-row scan flow: scan row 1, then row 2, and combine both scan results with a GS separator.
- Added parsing for GS1 AIs 01 (GTIN), 10 (lot/batch), 17 (expiration date), and 21 (serial number).
- Item registration stores the GTIN as the item barcode/code.
- Movement entry finds the item by GTIN and fills the lot and expiration fields when present.
- Kept the existing single-barcode scan flow unchanged.

Note: This is a sequential two-symbol scan workflow. Real-device validation is still required with the facility's actual GS1-128 label layouts and scanner output, especially where variable-length fields are used.

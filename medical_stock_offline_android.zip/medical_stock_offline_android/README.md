# 医療材料・試薬 在庫管理アプリ（完全オフライン版 1.9.0）

## 目的・動作方式
Androidスマートフォン1台で、インターネット・Wi-Fi・サーバーPCに接続せずに在庫を管理するためのAndroid Studioプロジェクトです。画面はアプリ内WebView、データは端末内IndexedDBに保存します。アプリからネットワークへ接続する権限は付与していません。

## 実装済み機能
- 品目マスター：品目名、コード、分類、保管場所、単位、発注点
- Androidカメラによるバーコード読取（ZXing。カメラ権限を使用）
- ロット別在庫・使用期限管理
- 入庫・出庫・廃棄（ロット指定、在庫不足時は登録拒否）
- 棚卸し調整（実在庫数を指定。0個への調整も可能。減少時は期限の早いロットから差し引き）
- 操作履歴
- 発注点以下、期限切れ、期限60日以内の警告
- JSONバックアップ・復元（復元時に形式と基本的なデータ整合性を検証）
- 在庫一覧CSV・履歴CSV出力（日本語Excel向けUTF-8 BOM付き）
- 前回バックアップから7日経過した際の画面内リマインダー
- ネットワーク権限なし。データは端末内に保存

## APKを作る手順
このZIPにはコンパイル済みAPKは含まれません。現在の作業環境にAndroid SDK/Gradleビルド環境がないため、APKの生成・実機テストは未完了です。

1. Windows PCにAndroid Studioをインストールします。
2. Android Studioでこのプロジェクトフォルダーを開きます。
3. 初回Gradle Sync時にインターネット接続し、Android SDK Platform 35、Gradleプラグイン、依存ライブラリを取得します。
4. `Build > Build APK(s)` を実行します。
5. `app/build/outputs/apk/debug/app-debug.apk` をUSBなどでAndroidスマホへコピーしてインストールします。
6. Android側で「この提供元からのアプリを許可」が必要になる場合があります。初回起動時にカメラ権限を許可するとバーコード読取が使えます。
7. インストール後の日常利用には、インターネット・Wi-Fi・サーバーPCは不要です。

## バックアップ運用
- 初回起動後、最初のデータ登録前後にJSONバックアップを作成してください。
- 以降は週1回を目安に「JSONバックアップを保存」を実行してください。
- バックアップ先は端末外の施設承認済み保存先を選んでください。端末内だけに保存すると、端末故障・紛失・アプリデータ消去時に復旧できません。
- 週次リマインダーはアプリを開いたときに表示されます。バックグラウンド通知ではありません。
- 復元は現在データを置き換えます。復元前に現在データもバックアップしてください。

## 重要な制限・実運用前の確認
- これは試作版です。正式運用前に、施設の情報セキュリティ担当者の承認を得てください。患者情報は登録しないでください。
- 端末内IndexedDBはアプリの領域に保存されますが、データベース自体を暗号化する実装は含みません。端末ロック、端末管理、バックアップファイルのアクセス制御を行ってください。
- 1台専用です。複数端末間の同期・共有機能はありません。
- Android端末の機種・OS・カメラ性能により、バーコード読取性能は異なります。
- 実在庫とアプリの残数を必ず照合してください。ロット番号・期限の運用ルールも現場に合わせて確認してください。
- 実機で、品目登録、カメラ読取、同一品目の複数ロット、期限別出庫、在庫不足時の出庫拒否、0個への棚卸し、CSV文字化け、JSON復元、端末再起動後のデータ保持をテストしてから使用してください。

## 技術構成
- Android：Java / AndroidX Activity
- 画面：HTML / CSS / JavaScript（Android WebView）
- ローカルDB：IndexedDB
- バーコード：ZXing Android Embedded
- バックアップ：Android Storage Access Framework
- 通信：Android INTERNET権限なし


## GS1-128 two-row scanning (v1.2.0)

Use the dedicated **GS1-128 2段読取** button. The app scans the first Code 128 symbol and then prompts for the second symbol. It combines the two decoded strings with an FNC1/group-separator boundary, parses AI (01) GTIN, AI (10) lot, AI (17) expiration date, and AI (21) serial number, then uses GTIN to find the registered item. Register each item with its GTIN in the item master first. During movement entry, a matching GTIN selects the item and fills lot/expiration when those fields were present.

This implementation assumes the printed two-row label consists of two independently scannable GS1-128 symbols. Validate with actual labels on the target Android device before operational use; some label layouts may encode data differently.


## v1.9.0 更新内容
- ロット別入庫日管理（同じロットでも入庫日が異なれば別在庫）
- 入庫日未入力時は登録日を自動設定
- 出庫・廃棄時に入庫日を含めた在庫ロットを選択
- 品目登録・入出庫の確定前確認画面
- 下部ナビゲーションとホーム画面の改善
- 既存IndexedDBデータを維持する更新方式

更新インストール前に必ずJSONバックアップを作成してください。既存のロットに実際の入庫日が記録されていない場合は「旧データ・不明」として保持され、推測で日付を付与しません。

**署名に関する注意：** 以前のAPKと今回のGitHub Actionsビルドで署名鍵が異なると、Androidは上書き更新を拒否します。先に旧アプリからJSONバックアップを端末外へ保存してください。上書き更新できればデータはそのまま残ります。署名不一致で更新できない場合のみ、バックアップを確認したうえで旧アプリをアンインストールし、新APKをインストールしてJSONを復元してください。再インストール後は管理者パスワードを再設定してください（操作者・品目・在庫・履歴はJSONに含まれます）。


## GitHub ActionsでAPKを作成
1. このZIPを展開し、フォルダー内のファイルを既存GitHubリポジトリのルートへアップロードします。
2. `.github/workflows/build-apk.yml` を含めて `main` または `master` ブランチへ反映します。
3. GitHubの Actions から `Build Android APK` を実行します（push時にも自動実行）。
4. 成功した実行の Artifacts から `medical-stock-v1.9.0-apk` をダウンロードし、ZIP内の `app-debug.apk` をAndroid端末へインストールします。

この作業環境にはAndroid SDKがないため、APKのコンパイルと実機インストール確認は未実施です。


## v1.9.1 changes

See `CHANGELOG_1.9.1.md`. This release applies the agreed five-tab UI, dashboard quick access and favorites, inventory filters, general-user item registration, administrator-only master edits, FEFO lot recommendation, and history filtering/cancellation. Existing IndexedDB database name and object stores are preserved.
